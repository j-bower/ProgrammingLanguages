#!/usr/bin/env bash

# Your solution for part 1 goes here.

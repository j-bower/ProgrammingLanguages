#!/usr/bin/env bash

# Your solution for part 2 goes here.

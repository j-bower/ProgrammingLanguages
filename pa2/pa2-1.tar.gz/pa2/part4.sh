#!/usr/bin/env bash

# Your solution for part 4 goes here.

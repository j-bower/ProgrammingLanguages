#!/usr/bin/env bash

# Your solution for part 3 goes here.
